package com.sj.repo.crud_mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
